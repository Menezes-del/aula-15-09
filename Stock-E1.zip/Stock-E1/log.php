<?php
session_start();

// Bloqueia acesso se não estiver logado
if (!isset($_SESSION["usuario"])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel Administrativo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            text-align: center;
            padding-top: 100px;
        }
        .painel {
            background: white;
            display: inline-block;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.15);
        }
        a {
            display: inline-block;
            margin-top: 20px;
            background: #dc3545;
            color: white;
            padding: 10px 15px;
            border-radius: 6px;
            text-decoration: none;
        }
        a:hover {
            background: #b02a37;
        }
    </style>
</head>
<body>
    <div class="painel">
        <h1>Bem-vindo, <?= htmlspecialchars($_SESSION["usuario"]) ?>!</h1>
        <p>Você está logado como administrador.</p>
        <a href="stock-e_Admin">Entrar</a>
    </div>
</body>
</html>

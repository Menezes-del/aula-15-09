<?php
session_start();

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "login_db";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

$sql = "SELECT * FROM admin LIMIT 1";
$result = $conn->query($sql);
$adminExists = $result->num_rows > 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = trim($_POST["usuario"]);
    $senha = trim($_POST["senha"]);

    if (!$adminExists) {
        $hash = password_hash($senha, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO admin (usuario, senha) VALUES (?, ?)");
        $stmt->bind_param("ss", $usuario, $hash);
        if ($stmt->execute()) {
            $_SESSION["usuario"] = $usuario;
            header("Location: log.php");
            exit();
        } else {
            $erro = "Erro ao cadastrar administrador.";
        }
    } else {
        $stmt = $conn->prepare("SELECT * FROM admin WHERE usuario = ?");
        $stmt->bind_param("s", $usuario);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($senha, $row["senha"])) {
                $_SESSION["usuario"] = $usuario;
                header("Location: log.php");
                exit();
            } else {
                $erro = "Senha incorreta.";
            }
        } else {
            $erro = "Usuário não encontrado.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title><?= $adminExists ? "Login do Administrador" : "Cadastro do Administrador" ?></title>
    <style>
        body {font-family: Arial, sans-serif; background-color: #eef2f3; display: flex; justify-content: center; align-items: center; height: 100vh;}
        form {background: white; padding: 30px; border-radius: 12px; box-shadow: 0 0 10px rgba(0,0,0,0.2); width: 320px; text-align: center;}
        input {width: 90%; padding: 10px; margin: 8px 0; border-radius: 6px; border: 1px solid #ccc;}
        button {background-color: #007bff; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer;}
        button:hover {background-color: #0056b3;}
        .erro {color: red; margin-bottom: 10px;}
    </style>
</head>
<body>
    <form method="POST">
        <h2><?= $adminExists ? "Login do Administrador" : "Cadastro do Administrador" ?></h2>
        <?php if (!empty($erro)) echo "<p class='erro'>$erro</p>"; ?>
        <input type="text" name="usuario" placeholder="Usuário" required><br>
        <input type="password" name="senha" placeholder="Senha" required><br>
        <button type="submit"><?= $adminExists ? "Entrar" : "Cadastrar" ?></button>
    </form>
</body>
</html>
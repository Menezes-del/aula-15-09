<?php
header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/db.php';

$tipos = ['conjunto','calcados','camisas','calcas','shorts'];
$generos = ['menino','menina'];

$sql = "SELECT p.tipo, p.genero, SUM(v.quantidade_vendida) AS total_vendido
        FROM vendas v
        JOIN produtos p ON p.id = v.produto_id
        WHERE MONTH(v.data_venda) = MONTH(CURDATE())
          AND YEAR(v.data_venda) = YEAR(CURDATE())
        GROUP BY p.tipo, p.genero";
$stmt = $pdo->query($sql);
$rows = $stmt->fetchAll();

$result = [];
foreach ($generos as $cat) {
    $dataset = ['genero' => $cat, 'valores' => []];
    foreach ($tipos as $t) {
        $val = 0;
        foreach ($rows as $r) {
            if ($r['tipo'] === $t && $r['genero'] === $cat) {
                $val = (int)$r['total_vendido'];
                break;
            }
        }
        $dataset['valores'][] = $val;
    }
    $result[] = $dataset;
}

echo json_encode(['tipos'=>$tipos,'generos'=>$generos,'dados'=>$result], JSON_UNESCAPED_UNICODE);
?>
<?php
include "db.php";

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = $pdo->prepare("DELETE FROM produtos WHERE id = ?");
    $ok = $sql->execute([$id]);

    if ($ok) {
        echo "Produto deletado com sucesso.";
    } else {
        echo "Erro ao deletar produto.";
    }
} else {
    echo "ID não informado.";
}
?>

<?php
header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/db.php';

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['id']) || !isset($data['quantidade'])) {
    echo json_encode(['success' => false, 'message' => 'Dados incompletos.']);
    exit;
}

$id = intval($data['id']);
$quantidade = intval($data['quantidade']);

$stmt = $pdo->prepare("UPDATE produtos SET quantidade = :quantidade WHERE id = :id");
$ok = $stmt->execute(['quantidade' => $quantidade, 'id' => $id]);

echo json_encode(['success' => $ok]);
?>

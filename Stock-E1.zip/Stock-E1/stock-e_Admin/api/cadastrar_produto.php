<?php
include "db.php"; // conexão $pdo

$modo = "cadastrar";
$produto = [
    "id" => "",
    "nome" => "",
    "preco" => "",
    "quantidade" => "",
    "genero" => "",
    "tipo" => "",
    "foto" => ""
];

// Se for alteração (editar produto)
if (isset($_GET['id'])) {
    $modo = "alterar";
    $id = intval($_GET['id']);
    $sql = $pdo->prepare("SELECT * FROM produtos WHERE id = ?");
    $sql->execute([$id]);
    $produto = $sql->fetch();
}

// Se enviou formulário (POST)
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = $_POST["nome"];
    $preco = $_POST["preco"];
    $quantidade = $_POST["quantidade"];
    $genero = $_POST["genero"];
    $tipo = $_POST["tipo"];

    // Upload da foto
    $foto = $produto["foto"];
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $nomeArq = uniqid('img_') . '.' . $ext;
        move_uploaded_file($_FILES['foto']['tmp_name'], "../uploads/" . $nomeArq);
        $foto = $nomeArq;
    }

    if ($modo === "cadastrar") {
        $sql = $pdo->prepare("INSERT INTO produtos 
            (nome, preco, quantidade, genero, tipo, data_cadastro, foto)
            VALUES (?, ?, ?, ?, ?, NOW(), ?)");
        $ok = $sql->execute([$nome, $preco, $quantidade, $genero, $tipo, $foto]);
    } else {
        $sql = $pdo->prepare("UPDATE produtos 
            SET nome=?, preco=?, quantidade=?, genero=?, tipo=?, foto=? WHERE id=?");
        $ok = $sql->execute([$nome, $preco, $quantidade, $genero, $tipo, $foto, $produto["id"]]);
    }

    if ($ok) {
        header("Location: ../index.html");
        exit;
    } else {
        echo "<p style='color:red'>Erro ao salvar produto.</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title><?= $modo === "cadastrar" ? "Cadastrar Produto" : "Alterar Produto" ?></title>
    <link rel="stylesheet" href="../form.css">
</head>
<body>
    <div class="form-container">
        <h1><?= $modo === "cadastrar" ? "Cadastrar Produto" : "Alterar Produto" ?></h1>

        <form action="cadastrar_produto.php<?= $modo === 'alterar' ? '?id='.$produto['id'] : '' ?>" 
              method="POST" enctype="multipart/form-data">
            
            <label>Nome:</label>
            <input type="text" name="nome" value="<?= htmlspecialchars($produto['nome']) ?>" required>

            <label>Preço:</label>
            <input type="number" step="0.01" name="preco" value="<?= htmlspecialchars($produto['preco']) ?>" required>

            <label>Quantidade:</label>
            <input type="number" name="quantidade" value="<?= htmlspecialchars($produto['quantidade']) ?>" required>

            <label>Gênero:</label>
            <select name="genero" required>
                <option value="">Selecione</option>
                <option value="Masculino" <?= $produto['genero'] === 'Masculino' ? 'selected' : '' ?>>Masculino</option>
                <option value="Feminino" <?= $produto['genero'] === 'Feminino' ? 'selected' : '' ?>>Feminino</option>
            </select>

            <label>Tipo:</label>
            <select name="tipo" required>
                <option value="">Selecione</option>
                <option value="Camisa" <?= $produto['tipo'] === 'Camisa' ? 'selected' : '' ?>>Camisa</option>
                <option value="Shorts" <?= $produto['tipo'] === 'Shorts' ? 'selected' : '' ?>>Shorts</option>
                <option value="Calçados" <?= $produto['tipo'] === 'Calçados' ? 'selected' : '' ?>>Calçados</option>
                <option value="Conjunto" <?= $produto['tipo'] === 'Conjunto' ? 'selected' : '' ?>>Conjunto</option>
                <option value="Calças" <?= $produto['tipo'] === 'Calças' ? 'selected' : '' ?>>Calças</option>
            </select>

            <label>Foto:</label>
            <input type="file" name="foto">
            <?php if (!empty($produto["foto"])): ?>
                <p>Foto atual:</p>
                <img src="../uploads/<?= $produto["foto"] ?>" alt="Foto do produto" width="150">
            <?php endif; ?>

            <div class="btn-group">
                <button type="submit" class="btn salvar">Salvar</button>
                <a href="../index.html" class="btn cancelar">Cancelar</a>
            </div>
        </form>
    </div>
</body>
</html>


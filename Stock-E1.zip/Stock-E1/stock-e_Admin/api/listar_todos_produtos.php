<?php
include "db.php";

header("Content-Type: application/json; charset=utf-8");

$sql = $pdo->query("SELECT * FROM produtos ORDER BY id DESC");
$produtos = $sql->fetchAll();

echo json_encode($produtos);
?>

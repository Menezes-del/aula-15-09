<?php
header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/db.php';

$stmt = $pdo->query("SELECT id, nome, preco, quantidade, genero, tipo FROM produtos ORDER BY nome ASC");
$rows = $stmt->fetchAll();

echo json_encode($rows, JSON_UNESCAPED_UNICODE);
?>
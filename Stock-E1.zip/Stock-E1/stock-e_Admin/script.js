document.addEventListener("DOMContentLoaded", () => {
    const menuItems = document.querySelectorAll(".sidebar nav ul li");
    const titulo = document.getElementById("titulo-bloco");
    const conteudo = document.getElementById("conteudo");

    function formatarTitulo(sec) {
        return sec.replace("-", " ").replace(/\b\w/g, l => l.toUpperCase());
    }

    // ------- MAIS VENDIDAS (gráfico empilhado por sexo no mês) -------
    function carregarMaisVendidas() {
        conteudo.innerHTML = "<p>Carregando dados...</p>";
        fetch("api/listar_vendas.php")
            .then(res => res.json())
            .then(json => {
                let html = "<h2>Genero (Tipos) mais vendidas no mês</h2>";
                html += `<canvas id="graficoVendas" style="margin-top:30px;"></canvas>`;
                conteudo.innerHTML = html;

                const ctx = document.getElementById('graficoVendas').getContext('2d');

                const cores = {
                    menino: "#3498db",
                    menina: "#e91e63"
                };

                const datasets = json.dados.map(d => ({
                    label: d.genero.charAt(0).toUpperCase() + d.genero.slice(1),
                    data: d.valores,
                    backgroundColor: cores[d.genero] || "#888"
                }));

                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: json.tipos.map(t => t.charAt(0).toUpperCase() + t.slice(1)),
                        datasets: datasets
                    },
                    options: {
                        responsive: true,
                        plugins: { legend: { position: 'top' } },
                        scales: {
                            x: { stacked: true },
                            y: { stacked: true, beginAtZero: true, ticks: { precision: 0 } }
                        }
                    }
                });
            })
            .catch(() => {
                conteudo.innerHTML = "<p class='msg-erro'>Não foi possível carregar o gráfico.</p>";
            });
    }

    // ------- PREÇOS -------
    function carregarPrecos() {
    conteudo.innerHTML = "<p>Carregando preços...</p>";
    fetch("api/listar_produtos.php")
        .then(res => res.json())
        .then(data => {
            let html = "<h2>Lista de Produtos</h2>";
            html += `
            <table class='tabela-precos'>
                <tr>
                    <th>Produto</th>
                    <th>Preço</th>
                    <th>Quantidade</th>
                    <th>genero</th>
                    <th>Tipo</th>
                </tr>`;
            data.forEach(item => {
                html += `
                    <tr data-id="${item.id}">
                        <td>${item.nome}</td>
                        <td>R$ ${Number(item.preco).toFixed(2)}</td>
                        <td class="quantidade-cell">
                            <button class="btn-quant menos">–</button>
                            <span class="quant">${item.quantidade}</span>
                            <button class="btn-quant mais">+</button>
                        </td>
                        <td>${item.genero || '-'}</td>
                        <td>${item.tipo || '-'}</td>
                    </tr>`;
            });
            html += "</table>";
            conteudo.innerHTML = html;

            // Eventos dos botões + e –
            document.querySelectorAll(".btn-quant").forEach(btn => {
                btn.addEventListener("click", async (e) => {
                    const linha = e.target.closest("tr");
                    const id = linha.getAttribute("data-id");
                    const span = linha.querySelector(".quant");
                    let qtd = parseInt(span.textContent);

                    if (e.target.classList.contains("mais")) qtd++;
                    else if (qtd > 0) qtd--;

                    span.textContent = qtd;

                    // Atualiza no banco
                    try {
                        const resp = await fetch("api/updateQuantidade.php", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ id: id, quantidade: qtd })
                        });
                        const json = await resp.json();
                        if (!json.success) {
                            alert("Erro ao atualizar quantidade!");
                        }
                    } catch {
                        alert("Falha ao conectar com o servidor.");
                    }
                });
            });
        })
        .catch(() => conteudo.innerHTML = "<p class='msg-erro'>Erro ao carregar preços.</p>");
}
    // ------- TODOS OS PRODUTOS (busca + 2 filtros + CRUD) -------
function carregarTodosProdutos() {
    conteudo.innerHTML = "<p>Carregando todos os produtos...</p>";
    fetch("api/listar_todos_produtos.php")
        .then(res => res.json())
        .then(data => {
            let html = `
                <h2>Todos os Produtos</h2>
                <div class="filtros-inline">
                    <input type="text" id="buscaProduto" placeholder="Buscar produto...">
                    <select id="filtrogenero">
                        <option value="todos">Todas as Genero</option>
                        <option value="menino">Menino</option>
                        <option value="menina">Menina</option>
                    </select>
                    <select id="filtroTipo">
                        <option value="todos">Todos os tipos</option>
                        <option value="conjunto">Conjunto</option>
                        <option value="calcados">Calçados</option>
                        <option value="camisas">Camisas</option>
                        <option value="calcas">Calças</option>
                        <option value="shorts">Shorts</option>
                    </select>
                </div>
                <div id="listaProdutos" style='display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:15px;'></div>
            `;
            conteudo.innerHTML = html;

            const lista = document.getElementById("listaProdutos");

            function renderizarProdutos(filtrados) {
                lista.innerHTML = "";
                if (filtrados.length === 0) {
                    lista.innerHTML = "<p>Nenhum produto encontrado.</p>";
                    return;
                }
                filtrados.forEach(item => {
                    const card = document.createElement("div");
                    card.className = "card-produto";
                    card.innerHTML = `
                        <img src="uploads/${item.foto || ''}" alt="${item.nome}">
                        <p><b>${item.nome}</b></p>
                        <p>R$ ${Number(item.preco).toFixed(2)}</p>
                        <small>genero: ${item.genero || '-'}</small><br>
                        <small>Tipo: ${item.tipo || '-'}</small>
                    `;

                    // --- clique no card → mostra botões CRUD ---
                    card.addEventListener("mouseenter", () => {
    let existente = card.querySelector(".botoes-crud");
    if (!existente) {
        const botoes = document.createElement("div");
        botoes.className = "botoes-crud";

        // Botão Alterar
        const btnAlterar = document.createElement("button");
        btnAlterar.textContent = "Alterar";
        btnAlterar.className = "btn-alterar";
        btnAlterar.addEventListener("click", (e) => {
            e.stopPropagation();
            window.location.href = `api/cadastrar_produto.php?id=${item.id}`;
        });

        // Botão Excluir
        const btnExcluir = document.createElement("button");
        btnExcluir.textContent = "Excluir";
        btnExcluir.className = "btn-excluir";
        btnExcluir.addEventListener("click", (e) => {
    e.stopPropagation();
    if (confirm(`Excluir "${item.nome}"?`)) {
        fetch(`api/deletar_produto.php?id=${item.id}`, { method: "GET" })
            .then(r => r.text())
            .then(resp => {
                alert(resp);
                carregarTodosProdutos();
            })
            .catch(() => alert("Erro ao excluir produto."));
    }
});

        botoes.appendChild(btnAlterar);
        botoes.appendChild(btnExcluir);
        card.appendChild(botoes);

        // Animação suave
        requestAnimationFrame(() => {
            botoes.classList.add("show");
        });
    }
});

        // Esconde os botões quando o mouse sai
        card.addEventListener("mouseleave", () => {
            const existente = card.querySelector(".botoes-crud");
            if (existente) {
                existente.classList.remove("show");
                setTimeout(() => existente.remove(), 300); // espera a animação terminar
            }
        });

                    lista.appendChild(card);
                });
            }

            renderizarProdutos(data);

            // --- filtros ---
            const inputBusca = document.getElementById("buscaProduto");
            const selectFiltro = document.getElementById("filtrogenero");
            const selectFiltroTipo = document.getElementById("filtroTipo");

            function aplicarFiltros() {
                const termo = inputBusca.value.toLowerCase();
                const cat = selectFiltro.value;
                const tipo = selectFiltroTipo.value;
                const filtrados = data.filter(item => {
                    const matchNome = item.nome.toLowerCase().includes(termo);
                    const matchCat = (cat === "todos" || (item.genero || "").toLowerCase() === cat);
                    const matchTipo = (tipo === "todos" || (item.tipo || "").toLowerCase() === tipo);
                    return matchNome && matchCat && matchTipo;
                });
                renderizarProdutos(filtrados);
            }

            inputBusca.addEventListener("input", aplicarFiltros);
            selectFiltro.addEventListener("change", aplicarFiltros);
            selectFiltroTipo.addEventListener("change", aplicarFiltros);
        })
        .catch(() => conteudo.innerHTML = "<p class='msg-erro'>Erro ao carregar produtos.</p>");
}


    // ------- CADASTRO -------
    function carregarCadastro() {
        conteudo.innerHTML = `
            <h2>Cadastrar Produto</h2>
            <form id="formCadastro" enctype="multipart/form-data">
                <input type="text" name="nome" placeholder="Nome da peça" required>
                <input type="number" step="0.01" name="preco" placeholder="Preço" required>
                <input type="number" name="quantidade" placeholder="Quantidade" required>
                <select name="genero">
                    <option value="menino">Menino</option>
                    <option value="menina">Menina</option>
                </select>
                <select name="tipo" required>
                    <option value="">Tipo da peça</option>
                    <option value="conjunto">Conjunto</option>
                    <option value="calcados">Calçados</option>
                    <option value="camisas">Camisas</option>
                    <option value="calcas">Calças</option>
                    <option value="shorts">Shorts</option>
                </select>
                <input type="file" name="foto" accept="image/*">
                <button type="submit">Cadastrar</button>
            </form>
            <div id="msgCadastro"></div>
        `;

        document.getElementById("formCadastro").addEventListener("submit", e => {
            e.preventDefault();
            const formData = new FormData(e.target);
            fetch("api/cadastrar_produto.php", {
                method: "POST",
                body: formData
            })
            .then(res => res.text())
            .then(msg => {
                document.getElementById("msgCadastro").innerHTML =
                    `<p class="msg-sucesso">${msg}</p>`;
                carregarTodosProdutos();
            })
            .catch(() => {
                document.getElementById("msgCadastro").innerHTML =
                    `<p class="msg-erro">Erro ao cadastrar produto.</p>`;
            });
        });
    }

    menuItems.forEach(item => {
        item.addEventListener("click", () => {
            menuItems.forEach(i => i.classList.remove("ativo"));
            item.classList.add("ativo");

            const section = item.getAttribute("data-section");
            titulo.textContent = formatarTitulo(section);

            if (section === "mais-vendidas") carregarMaisVendidas();
            if (section === "precos") carregarPrecos();
            if (section === "todos-produtos") carregarTodosProdutos();
            if (section === "cadastro") carregarCadastro();
        });
    });

    carregarMaisVendidas();
});
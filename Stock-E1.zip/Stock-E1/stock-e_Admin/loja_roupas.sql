-- Banco de dados: loja_roupas
-- Versão unificada com campo 'genero' e coluna 'tipo'
-- Autor: atualização GPT-5
-- Data: 2025-10-06

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
SET NAMES utf8mb4;

-- ================================================
-- CRIAÇÃO DO BANCO
-- ================================================
CREATE DATABASE IF NOT EXISTS loja_roupas
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE loja_roupas;

-- ================================================
-- TABELA: produtos
-- ================================================
DROP TABLE IF EXISTS produtos;

CREATE TABLE produtos (
  id INT(11) NOT NULL AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  preco DECIMAL(10,2) NOT NULL,
  quantidade INT(11) NOT NULL,
  genero VARCHAR(50) DEFAULT NULL,    -- Substitui 'categoria'
  tipo VARCHAR(50) DEFAULT NULL,      -- Campo adicionado
  data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP,
  foto VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ================================================
-- DADOS INICIAIS
-- ================================================
INSERT INTO produtos (id, nome, preco, quantidade, genero, tipo, data_cadastro, foto) VALUES
(1, 'Pijama Masculino', 129.90, 5, 'menino', 'conjunto', '2025-08-14 14:19:19', NULL),
(2, 'Pijama Feminino', 159.90, 10, 'menina', 'conjunto', '2025-08-14 14:40:31', 'pijama_feminino.webp'),
(3, 'Meia Dragon Ball Masculina', 15.00, 30, 'menino', 'calcados', '2025-08-14 14:42:55', 'GOAT.jpg'),
(4, 'Shorts de Elefante', 49.90, 8, 'menino', 'shorts', '2025-08-14 14:45:48', 'S21ce4a367df4439489a9fff7ebb90dbeR.jpg');

-- ================================================
-- TABELA: vendas
-- ================================================
DROP TABLE IF EXISTS vendas;

CREATE TABLE vendas (
  id INT(11) NOT NULL AUTO_INCREMENT,
  produto_id INT(11) NOT NULL,
  quantidade_vendida INT(11) NOT NULL,
  data_venda DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY produto_id (produto_id),
  CONSTRAINT vendas_ibfk_1 FOREIGN KEY (produto_id) REFERENCES produtos (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

COMMIT;
